<?php
/**
 * CommenterCard 评论者信息卡片
 * 
 * @package CommenterCard
 * @author Lin.
 * @version 1.0.2
 * @link https://linyu.live
 * @copyright Lin. (https://linyu.live)
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class CommenterCard_Plugin implements Typecho_Plugin_Interface
{
    const VERSION = '1.0.2';

    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'injectHeader');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'injectFooter');
        return _t('插件已激活');
    }
    public static function deactivate() { return _t('插件已禁用'); }
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Textarea('levelRules', NULL, "0,访客\n10,落座\n50,熟客\n100,故友\n200,知己", _t('等级规则'), _t('评论数,称号')));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('authorMail', NULL, '', _t('博主邮箱'), NULL));
    }
    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    public static function injectHeader()
    {
        // 本地 jQuery，去掉 bootcdn 依赖
        echo '<script src="' . Helper::options()->themeUrl . '/static/js/jquery.min.js"></script>' . "\n";
        $cssUrl = Helper::options()->pluginUrl . '/CommenterCard/card.css';
        echo '<link rel="stylesheet" href="' . $cssUrl . '?v=' . self::VERSION . '" type="text/css" />' . "\n";
    }

    public static function injectFooter()
    {
        $cfg = Typecho_Widget::widget('Widget_Options')->plugin('CommenterCard') ?: new stdClass();
        $db = Typecho_Db::get();

        $rules = array();
        foreach (explode("\n", $cfg->levelRules ?? '') as $l) {
            $l = trim($l); if (!$l) continue;
            $p = explode(',', $l, 2);
            if (count($p) === 2) $rules[] = array(intval($p[0]), trim($p[1]));
        }
        usort($rules, function($a, $b) { return $a[0] - $b[0]; });

        $aMail = strtolower(trim($cfg->authorMail ?? ''));

        $rows = $db->fetchAll($db->select('mail','author','url','ip','created','text')
            ->from('table.comments')->where('status=?','approved')
            ->order('created', Typecho_Db::SORT_DESC)->limit(100));

        $u = array();
        foreach ($rows as $r) {
            $mk = strtolower(trim($r['mail']??'')); if (!$mk) continue;
            if (!isset($u[$mk])) $u[$mk] = array('n'=>$r['author']??'','u'=>$r['url']??'','i'=>$r['ip']??'','t'=>intval($r['created']??0),'c'=>0,'r'=>array());
            $u[$mk]['c']++;
            if (count($u[$mk]['r'])<3) $u[$mk]['r'][] = array(mb_strimwidth(strip_tags($r['text']??''),0,28,'…','UTF-8'), date('m-d H:i',intval($r['created'])));
        }

        $d = array(); $n = array();
        foreach ($u as $mk=>$v) {
            $lv = '';
            foreach ($rules as $rl) { if ($rl[0] <= $v['c']) $lv = $rl[1]; }
            $nm = $v['n'] ?: '访客';
            $au = !empty($aMail) && $mk === $aMail;
            $item = array('name'=>$nm,'url'=>$v['u'],'count'=>$v['c'],'level'=>$lv,'ip'=>$v['i'],'lastTime'=>$v['t']?date('Y-m-d H:i',$v['t']):'','recent'=>$v['r'],'author'=>$au);
            $d[md5($mk)] = $item;
            if (!isset($n[$nm])) $n[$nm] = $item;
        }

        // 只输出动态数据 + 外部 JS 引用
        echo '<script>window._ccd='.json_encode($d).';window._ccn='.json_encode($n).';window._ccp='.json_encode(Helper::options()->pluginUrl.'/CommenterCard/ip.php').';window._ccv=2;</script>';
        $jsUrl = Helper::options()->pluginUrl . '/CommenterCard/card.js';
        echo '<script src="' . $jsUrl . '?v=' . self::VERSION . '"></script>' . "\n";
    }
}
