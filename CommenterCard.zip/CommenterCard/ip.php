<?php
/**
 * CommenterCard 代理接口 —— IP查询 + 网站在线检测
 *
 * @version 1.0.0
 * @link https://linyu.live
 * @copyright Lin. (https://linyu.live)
 */

$ip = $_GET['ip'] ?? '';
$check = $_GET['check'] ?? '';

// 在线检测
if (!empty($check)) {
    if (!filter_var($check, FILTER_VALIDATE_URL)) {
        header('Content-Type: application/json');
        echo json_encode(array('online' => false));
        exit;
    }
    $ctx = stream_context_create(array('http' => array('timeout' => 4, 'user_agent' => 'Mozilla/5.0')));
    $res = @file_get_contents($check, false, $ctx);
    $headers = $http_response_header ?? array();
    $online = false;
    foreach ($headers as $h) {
        if (strpos($h, '200') !== false || strpos($h, '301') !== false || strpos($h, '302') !== false) {
            $online = true; break;
        }
    }
    header('Content-Type: application/json');
    echo json_encode(array('online' => $online));
    exit;
}

// IP查询
if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
    header('Content-Type: application/json');
    echo json_encode(array('loc' => ''));
    exit;
}

$url = 'http://ip-api.com/json/' . urlencode($ip) . '?lang=zh-CN&fields=status,regionName,city';
$loc = '';
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 2, CURLOPT_CONNECTTIMEOUT => 1));
    $res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code == 200 && ($d = json_decode($res, true)) && ($d['status'] ?? '') === 'success') {
        $parts = array_filter(array($d['regionName'] ?? '', $d['city'] ?? ''));
        $loc = implode('', $parts);
    }
}
header('Content-Type: application/json');
echo json_encode(array('loc' => $loc));
