/**
 * CommenterCard 前端 v3
 * 两段式布局：头像只带前3行，下方内容跨行左对齐
 * @version 1.0.0
 * @link https://linyu.live
 */
(function(){
'use strict';

var D,N,I,O,P,card=null,timer=null,bound=false;
function refresh(){
    D=window._ccd||{};
    N=window._ccn||{};
    I=window._cci||'';
    O=(window._cco!==undefined?window._cco:15)/100;
    P=window._ccp||'';
}

function md5(s){
function RL(v,n){return(v<<n)|(v>>>(32-n));}
function AU(x,y){var x4=x&0x40000000,y4=y&0x40000000,r=(x&0x3FFFFFFF)+(y&0x3FFFFFFF);if(x4&y4)return r^0x80000000^x4^y4;if(x4|y4)return(r&0x40000000)?r^0xC0000000^x4^y4:r^0x40000000^x4^y4;return r^x4^y4;}
function F(x,y,z){return(x&y)|((~x)&z);}function G(x,y,z){return(x&z)|(y&(~z));}function H(x,y,z){return x^y^z;}function I_(x,y,z){return y^(x|(~z));}
function FF(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(F(b,c,d),x),ac),a),s),b);}
function GG(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(G(b,c,d),x),ac),a),s),b);}
function HH(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(H(b,c,d),x),ac),a),s),b);}
function II(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(I_(b,c,d),x),ac),a),s),b);}
var ua='',la=s.length,nt=la+8,nw=((nt-(nt%64))/64+1)*16,wa=new Array(nw-1),bp=0,bc=0;
while(bc<la){var wc=(bc-(bc%4))/4,bp_=(bc%4)*8;wa[wc]=(wa[wc]|(s.charCodeAt(bc)<<bp_));bc++;}
var wc=(bc-(bc%4))/4,bp_=(bc%4)*8;wa[wc]=wa[wc]|(0x80<<bp_);wa[nw-2]=la<<3;wa[nw-1]=la>>>29;
for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)ua+=String.fromCharCode(c);else if(c<2048)ua+=String.fromCharCode((c>>6)|192,(c&63)|128);else ua+=String.fromCharCode((c>>12)|224,((c>>6)&63)|128,(c&63)|128);}
la=ua.length;nt=la+8;nw=((nt-(nt%64))/64+1)*16;wa=new Array(nw-1);bp=0;bc=0;
while(bc<la){wc=(bc-(bc%4))/4;bp_=(bc%4)*8;wa[wc]=(wa[wc]|(ua.charCodeAt(bc)<<bp_));bc++;}
wc=(bc-(bc%4))/4;bp_=(bc%4)*8;wa[wc]=wa[wc]|(0x80<<bp_);wa[nw-2]=la<<3;wa[nw-1]=la>>>29;
var x=[],a=0x67452301,b=0xEFCDAB89,c=0x98BADCFE,d=0x10325476;
for(var k=0;k<wa.length;k+=16){
var AA=a,BB=b,CC=c,DD=d;
a=FF(a,b,c,d,wa[k+0],7,0xD76AA478);d=FF(d,a,b,c,wa[k+1],12,0xE8C7B756);c=FF(c,d,a,b,wa[k+2],17,0x242070DB);b=FF(b,c,d,a,wa[k+3],22,0xC1BDCEEE);
a=FF(a,b,c,d,wa[k+4],7,0xF57C0FAF);d=FF(d,a,b,c,wa[k+5],12,0x4787C62A);c=FF(c,d,a,b,wa[k+6],17,0xA8304613);b=FF(b,c,d,a,wa[k+7],22,0xFD469501);
a=FF(a,b,c,d,wa[k+8],7,0x698098D8);d=FF(d,a,b,c,wa[k+9],12,0x8B44F7AF);c=FF(c,d,a,b,wa[k+10],17,0xFFFF5BB1);b=FF(b,c,d,a,wa[k+11],22,0x895CD7BE);
a=FF(a,b,c,d,wa[k+12],7,0x6B901122);d=FF(d,a,b,c,wa[k+13],12,0xFD987193);c=FF(c,d,a,b,wa[k+14],17,0xA679438E);b=FF(b,c,d,a,wa[k+15],22,0x49B40821);
a=GG(a,b,c,d,wa[k+1],5,0xF61E2562);d=GG(d,a,b,c,wa[k+6],9,0xC040B340);c=GG(c,d,a,b,wa[k+11],14,0x265E5A51);b=GG(b,c,d,a,wa[k+0],20,0xE9B6C7AA);
a=GG(a,b,c,d,wa[k+5],5,0xD62F105D);d=GG(d,a,b,c,wa[k+10],9,0x2441453);c=GG(c,d,a,b,wa[k+15],14,0xD8A1E681);b=GG(b,c,d,a,wa[k+4],20,0xE7D3FBC8);
a=GG(a,b,c,d,wa[k+9],5,0x21E1CDE6);d=GG(d,a,b,c,wa[k+14],9,0xC33707D6);c=GG(c,d,a,b,wa[k+3],14,0xF4D50D87);b=GG(b,c,d,a,wa[k+8],20,0x455A14ED);
a=HH(a,b,c,d,wa[k+5],4,0xFFFA3942);d=HH(d,a,b,c,wa[k+8],11,0x8771F681);c=HH(c,d,a,b,wa[k+11],16,0x6D9D6122);b=HH(b,c,d,a,wa[k+14],23,0xFDE5380C);
a=HH(a,b,c,d,wa[k+1],4,0xA4BEEA44);d=HH(d,a,b,c,wa[k+4],11,0x4BDECFA9);c=HH(c,d,a,b,wa[k+7],16,0xF6BB4B60);b=HH(b,c,d,a,wa[k+10],23,0xBEBFBC70);
a=II(a,b,c,d,wa[k+0],6,0xF4292244);d=II(d,a,b,c,wa[k+7],10,0x432AFF97);c=II(c,d,a,b,wa[k+14],15,0xAB9423A7);b=II(b,c,d,a,wa[k+5],21,0xFC93A039);
a=AU(a,AA);b=AU(b,BB);c=AU(c,CC);d=AU(d,DD);
}
function W(v){var h='',t;for(var i=0;i<=3;i++){t=(v>>>(i*8))&255;h+='0'+t.toString(16);}return h.substr(-8);}
return(W(a)+W(b)+W(c)+W(d)).toLowerCase();
}

function esc(t){if(typeof t!=='string')return t;var d=document.createElement('div');d.appendChild(document.createTextNode(t));return d.innerHTML;}

function getName($a){
var alt=$a.attr('alt')||'';if(alt&&alt!=='头像')return alt;
var $p=$a.closest('.comment-item,.comment-parent,.comment-child,li');
var $n=$p.find('.name,.comment-author,.author-name,.author,.comment-nick,[class*="author"]');
if($n.length){var t=$n.first().text().trim();if(t)return t.split(/\s+/)[0];}
$n=$a.parent().find('.name,.comment-author,.author-name,.author');
if($n.length){var s=$n.first().text().trim();if(s)return s.split(/\s+/)[0];}
return'';
}

function tAvatar(n,s){
var c=document.createElement('canvas');c.width=s;c.height=s;
var x=c.getContext('2d'),cl=['#60a5fa','#34d399','#a78bfa','#f472b6','#38bdf8','#fbbf24'];
x.fillStyle=cl[(n||'?').charCodeAt(0)%cl.length];x.beginPath();x.arc(s/2,s/2,s/2,0,Math.PI*2);x.fill();
x.fillStyle='#fff';x.font='bold '+Math.floor(s*0.42)+'px sans-serif';x.textAlign='center';x.textBaseline='middle';
x.fillText((n||'?').charAt(0),s/2,s/2+1);return c.toDataURL('image/png');
}

function find($a){
refresh();
var mail=$a.data('mail')||$a.closest('[data-mail]').data('mail');
if(mail){var k=md5(mail.toLowerCase());if(D[k])return D[k];}
var src=$a.attr('src')||'',m=src.match(/\/avatar\/([a-f0-9]{32})/i);
if(m){var k2=m[1].toLowerCase();if(D[k2])return D[k2];}
var nm=getName($a);if(nm&&N[nm])return N[nm];
var $p=$a.closest('.comment-item,.comment-parent,.comment-child,li');
var $ml=$p.find('a[href^="mailto:"]');
if($ml.length){var mh=$ml.attr('href').replace('mailto:','');if(mh){var k3=md5(mh.toLowerCase());if(D[k3])return D[k3];}}
return{name:nm||'访客',url:'',count:0,level:'',ip:'',lastTime:'',recent:[],author:false};
}

// ========== 定位：PC 右侧（右边留白40px），移动端优先下方 ==========
function pos($a,$c){
var ao=$a.offset(),aw=$a.outerWidth(),ah=$a.outerHeight(),ch=$c.outerHeight(),cw=$c.outerWidth(),ww=$(window).width(),wh=$(window).height(),st=$(window).scrollTop();
var isMobile=ww<768;
var left,top,belowY,aboveY;

// 用卡片真实高度计算，上方留 16px gap
if(isMobile){
left=ao.left;
// 优先下方
var belowY=ao.top+ah+12;
if(belowY+ch>st+wh-20){// 下方不够放上方
// 重新测量真实高度
var realH=$c.outerHeight();
top=Math.max(st+8,ao.top-realH-16);
$c.addClass('cc-above');
}else{top=belowY;}
if(left+cw>ww-20){left=Math.max(10,ww-cw-20);}
}else{
// PC 优先右侧
left=ao.left+aw+18;
top=ao.top-4;
if(left+cw>ww-40){left=Math.max(40,ao.left-cw-18);}
// 垂直调整：用真实高度
var realH2=$c.outerHeight();
if(top<st+12){top=ao.top+ah+12;}// 上方不够放下方
else if(top+realH2>st+wh-20){// 下方不够放上方
// 上方位置 = 头像顶部 - 真实高度 - gap
top=Math.max(st+8,ao.top-realH2-16);
$c.addClass('cc-above');
}
}

$c.css({top:top,left:left});
}

// ========== RSS ==========
function loadFeed(url){
if(!url||!P)return;
var ck='cc_feed_'+md5(url),cd=null;
try{cd=JSON.parse(localStorage.getItem(ck));}catch(e){}
// 缓存版本检测：如果插件版本变了或缓存格式不对（无v2标记），强制刷新
if(cd&&cd.ts&&cd.v===(window._ccv||1)&&((Date.now()-cd.ts)<86400000)){renderFeed(url,cd.data);return;}
$.ajax({url:P,type:'GET',data:{feed:url},dataType:'json',timeout:6000,
success:function(r){if(!r)return;try{localStorage.setItem(ck,JSON.stringify({data:r,ts:Date.now(),v:window._ccv||1}));}catch(e){}renderFeed(url,r);},
error:function(){renderFeed(url,{desc:'',articles:[]});}
});
}

function renderFeed(url,data){
if(!card)return;
if(card.attr('data-url')!==url)return;
var desc=(data&&data.desc)?data.desc:'';
var articles=(data&&data.articles)?data.articles:[];
if(desc){card.find('.cc-subtitle').text(desc).addClass('cc-subtitle-ready');}else{card.find('.cc-subtitle').hide();}
var vbtn=url?'<a class="cc-visit-inline" href="'+esc(url)+'" target="_blank" rel="noopener">访问 ›</a>':'';
if(articles&&articles.length){
var html='';
$.each(articles,function(i,a){
var link=a.link?esc(a.link):'';var title=esc(a.title);var adate=a.date?'<span class="cc-item-date">'+esc(a.date)+'</span>':'';
if(link){html+='<a class="cc-list-item" href="'+link+'" target="_blank" rel="noopener"><span class="cc-item-dot"></span><span class="cc-item-title">'+title+'</span>'+adate+'</a>';}
else{html+='<div class="cc-list-item"><span class="cc-item-dot"></span><span class="cc-item-title">'+title+'</span>'+adate+'</div>';}
});
card.find('.cc-list').html('<div class="cc-section-header"><span class="cc-section-title">最新文章</span>'+vbtn+'</div>'+html).show().addClass('cc-list-ready');
card.find('.cc-recent-section').hide();
}else{
card.find('.cc-list').hide();
}
}

// ========== 显示卡片（两段式布局） ==========
function show($a){
clearTimeout(timer);
var d=find($a);
if(card){card.remove();card=null;}
var av=$a.attr('src')||'';
if(!av||/avatar\.svg|00000000000000000000000000000000|default|placeholder/i.test(av))av=tAvatar(d.name,80);

var bg=(I&&O>0.01)?'<img class="cc-bg" src="'+esc(I)+'" alt="" style="opacity:'+O+'"/>':'';
var bd=d.author?'<span class="cc-badge cc-badge-author">博主</span>':(d.level?'<span class="cc-badge cc-badge-level">'+esc(d.level)+'</span>':'');
var nc=d.author?'cc-name cc-name-author':'cc-name';
var ip=d.ip?'<span class="cc-ip-tag" data-ip="'+esc(d.ip)+'"></span>':'';

// header：头像 + 名字/副标题/网址
var header='<div class="cc-header"><img class="cc-avatar" src="'+av+'" alt=""/><div class="cc-header-info">'
+'<div class="cc-name-line"><span class="'+nc+'">'+esc(d.name)+'</span>'+bd+ip+'</div>'
+(d.url?'<div class="cc-subtitle" data-feed="'+esc(d.url)+'">...</div>':'')
+(d.url?'<div class="cc-url-line"><a class="cc-url-link" href="'+esc(d.url)+'" target="_blank" rel="noopener">'+esc(d.url.replace(/^https?:\/\//,'').replace(/\/$/,''))+'</a><span class="cc-status" data-check="'+esc(d.url)+'"><span class="cc-status-dot cc-status-loading"></span>检测中</span></div>':'')
+'</div></div>';

// body：最新互动 + 评论数 + 列表
var body='<div class="cc-body">'
+(d.lastTime?'<div class="cc-time">最近互动 '+esc(d.lastTime)+'</div>':'')
+'<div class="cc-count">评论: <b>'+(d.count||0)+'</b></div>';

// 评论列表（默认显示）
var vbtn=d.url?'<a class="cc-visit-inline" href="'+esc(d.url)+'" target="_blank" rel="noopener">访问 ›</a>':'';
if(d.recent&&d.recent.length){
var items='';
$.each(d.recent,function(i,r){items+='<div class="cc-list-item"><span class="cc-item-dot"></span><span class="cc-item-title">'+esc(r[0])+'</span><span class="cc-item-date">'+esc(r[1])+'</span></div>';});
body+='<div class="cc-recent-section"><div class="cc-section-header"><span class="cc-section-title">最新评论</span>'+vbtn+'</div>'+items+'</div>';
}

// 文章列表占位（异步填充）
if(d.url){
body+='<div class="cc-list" data-feed="'+esc(d.url)+'" style="display:none"></div>';
}

body+='</div>';

card=$('<div class="commenter-card" id="cc-popup"><div class="cc-box">'+bg+header+body+'</div></div>').appendTo('body');
card.attr('data-url',d.url||'');

if($('body').hasClass('dark')||$('body').hasClass('dark-mode')||$('html').hasClass('dark')||$('html').attr('data-theme')==='dark'||$('body').attr('data-theme')==='dark')card.find('.cc-box').addClass('cc-dark');
pos($a,card);requestAnimationFrame(function(){card.addClass('cc-show');});
// 异步内容加载后二次校正位置
setTimeout(function(){if(card)pos($a,card);},120);

card.on('mouseenter.cc',function(){clearTimeout(timer);}).on('mouseleave.cc',function(){clearTimeout(timer);timer=setTimeout(function(){if(card){card.addClass('cc-hide');setTimeout(function(){if(card){card.remove();card=null;}},180);}},200);});

if(d.ip&&P)$.ajax({url:P,type:'GET',data:{ip:d.ip},dataType:'json',timeout:3000,success:function(r){if(card&&r&&r.loc)card.find('.cc-ip-tag').html('<span class="cc-ip-dot"></span>IP '+esc(r.loc));}});
if(d.url&&P)$.ajax({url:P,type:'GET',data:{check:d.url},dataType:'json',timeout:5000,success:function(r){if(!card)return;var $s=card.find('.cc-status');if(r&&r.online)$s.html('<span class="cc-status-dot cc-status-on"></span>在线').addClass('cc-status-online');else $s.html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');},error:function(){if(card)card.find('.cc-status').html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');}});
if(d.url&&P)loadFeed(d.url);
}

// ========== 绑定 ==========
function bind(){
if(bound)return;
refresh();
$(document).off('mouseenter.cdc mouseleave.cdc').on('mouseenter.cdc','img.avatar',function(){show($(this));}).on('mouseleave.cdc','img.avatar',function(){clearTimeout(timer);timer=setTimeout(function(){if(card){card.addClass('cc-hide');setTimeout(function(){if(card){card.remove();card=null;}},180);}},200);});
bound=true;
}

if(typeof jQuery!=='undefined')bind();
document.addEventListener('DOMContentLoaded',function(){if(typeof jQuery!=='undefined')bind();});
window.addEventListener('load',function(){if(typeof jQuery!=='undefined')bind();});
var _r=0,_t=setInterval(function(){if(typeof jQuery!=='undefined'){bind();clearInterval(_t);}_r++;if(_r>20)clearInterval(_t);},300);
$(document).on('pjax:end turbolinks:load page:loaded',function(){bound=false;setTimeout(function(){if(typeof jQuery!=='undefined')bind();},200);});
window._ccInit=function(){bound=false;bind();};
})();
