/**
 * CommenterCard 前端
 *
 * @version 1.0.0
 * @link https://linyu.live
 * @copyright Lin. (https://linyu.live)
 */
(function($) {
    'use strict';

    var DATA = {};
    var CORNER_IMG = '';
    var CORNER_OPACITY = 0.15;
    var IP_API = '';
    var card = null, hideTimer = null;

    /**
     * 读取页面注入的数据
     */
    function readData() {
        DATA = window._ccData || {};
        CORNER_IMG = window._ccCornerImg || '';
        CORNER_OPACITY = (window._ccCornerOpacity !== undefined ? window._ccCornerOpacity : 15) / 100;
        IP_API = window._ccIpApi || '';
    }

    /**
     * 从头像元素提取匹配 key
     */
    function getKey($avatar) {
        var mail = $avatar.data('mail') || $avatar.closest('[data-mail]').data('mail');
        if (mail) return md5(mail.toLowerCase());
        var src = $avatar.attr('src') || '';
        var m = src.match(/\/avatar\/([a-f0-9]{32})/i);
        if (m) return m[1].toLowerCase();
        var $item = $avatar.closest('.comment-item, .comment-parent, .comment-child');
        var $mailLink = $item.find('a[href^="mailto:"]');
        if ($mailLink.length) {
            var mailHref = $mailLink.attr('href').replace('mailto:', '');
            if (mailHref) return md5(mailHref.toLowerCase());
        }
        var alt = $avatar.attr('alt') || '';
        if (alt && alt !== '头像') return md5('author:' + alt.toLowerCase());
        return '';
    }

    /**
     * 从头像周边 DOM 提取评论者名字
     */
    function getName($avatar) {
        var alt = $avatar.attr('alt') || '';
        if (alt && alt !== '头像') return alt;
        var $item = $avatar.closest('.comment-item, .comment-parent, .comment-child');
        var $name = $item.find('.name, .comment-author, .author-name, .author, [class*="author"]');
        if ($name.length) {
            var t = $name.first().text().trim();
            if (t) return t.split(/\s+/)[0];
        }
        var $sibling = $avatar.parent().find('.name, .comment-author, .author-name, .author');
        if ($sibling.length) {
            var st = $sibling.first().text().trim();
            if (st) return st.split(/\s+/)[0];
        }
        var mail = $avatar.data('mail') || '';
        if (mail) return mail.split('@')[0];
        return '';
    }

    function textAvatar(name, size) {
        var canvas = document.createElement('canvas');
        canvas.width = size; canvas.height = size;
        var ctx = canvas.getContext('2d');
        var colors = ['#60a5fa','#34d399','#a78bfa','#f472b6','#38bdf8','#fbbf24'];
        var ch = (name || '?').charCodeAt(0);
        ctx.fillStyle = colors[ch % colors.length];
        ctx.beginPath(); ctx.arc(size/2, size/2, size/2, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = 'bold ' + Math.floor(size*0.42) + 'px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText((name || '?').charAt(0), size/2, size/2 + 1);
        return canvas.toDataURL('image/png');
    }

    function getAvatar($avatar, name) {
        var src = $avatar.attr('src') || '';
        if (!src || src.indexOf('avatar.svg') !== -1 || src.indexOf('00000000000000000000000000000000') !== -1 || src.indexOf('default') !== -1 || src.indexOf('placeholder') !== -1) {
            return textAvatar(name, 80);
        }
        return src;
    }

    function findDataByName(name) {
        if (!name) return null;
        for (var k in DATA) {
            if (DATA[k] && DATA[k].name === name) {
                return DATA[k];
            }
        }
        return null;
    }

    function showCard($avatar) {
        clearTimeout(hideTimer);

        var key = getKey($avatar);
        var d = key ? DATA[key] : null;

        if (!d) {
            var name = getName($avatar);
            if (name) d = findDataByName(name);
        }

        if (!d) {
            var fallbackName = getName($avatar) || '访客';
            d = { name: fallbackName, url: '', count: 0, level: '', ip: '', lastTime: '', recent: [], author: false };
        }

        if (card) { card.remove(); card = null; }

        var avatar = getAvatar($avatar, d.name);

        var badge = '';
        if (d.author) {
            badge = '<span class="cc-badge cc-badge-author">博主</span>';
        } else if (d.level) {
            badge = '<span class="cc-badge cc-badge-level">' + esc(d.level) + '</span>';
        }

        var nameClass = d.author ? 'cc-name cc-name-author' : 'cc-name';
        var ipTag = d.ip ? '<span class="cc-ip-tag" data-ip="' + esc(d.ip) + '"></span>' : '';

        var urlLine = '';
        if (d.url) {
            urlLine = '<div class="cc-url-line">'
                + '<a class="cc-url-link" href="' + esc(d.url) + '" target="_blank" rel="noopener">' + esc(d.url.replace(/^https?:\/\//, '').replace(/\/$/, '')) + '</a>'
                + '<span class="cc-status" data-check="' + esc(d.url) + '"><span class="cc-status-dot cc-status-loading"></span>检测中</span>'
                + '</div>';
        }

        var timeLine = d.lastTime ? '<div class="cc-time">最近互动 ' + esc(d.lastTime) + '</div>' : '';
        var countLine = '<div class="cc-count">评论: <b>' + (d.count || 0) + '</b></div>';

        var recentLine = '';
        if (d.recent && d.recent.length) {
            var items = '';
            $.each(d.recent, function(i, r) {
                items += '<div class="cc-recent-item"><span class="cc-recent-text">' + esc(r.text) + '</span><span class="cc-recent-date">' + esc(r.date) + '</span></div>';
            });
            recentLine = '<div class="cc-recent">' + items + '</div>';
        }

        var visitBtn = d.url ? '<a class="cc-visit" href="' + esc(d.url) + '" target="_blank" rel="noopener">访问</a>' : '';

        // 背景图
        var bgImg = '';
        if (CORNER_IMG) {
            bgImg = '<img class="cc-bg" src="' + esc(CORNER_IMG) + '" alt="" style="opacity:' + CORNER_OPACITY + '" />';
        }

        var html = '<div class="commenter-card" id="cc-popup">'
            + '<div class="cc-box">'
            + bgImg
            + '<div class="cc-main">'
            + '<img class="cc-avatar" src="' + avatar + '" alt=""/>'
            + '<div class="cc-info">'
            + '<div class="cc-name-line">'
            + '<span class="' + nameClass + '">' + esc(d.name) + '</span>'
            + badge
            + ipTag
            + '</div>'
            + urlLine
            + timeLine
            + countLine
            + recentLine
            + '</div></div>'
            + visitBtn
            + '</div></div>';

        card = $(html).appendTo('body');

        // 暗色检测
        var isDark = $('body').hasClass('dark') || $('body').hasClass('dark-mode') || $('html').hasClass('dark') || $('html').attr('data-theme') === 'dark' || $('body').attr('data-theme') === 'dark';
        if (isDark) {
            card.find('.cc-box').addClass('cc-dark');
        }

        positionCard($avatar, card);
        requestAnimationFrame(function() { card.addClass('cc-show'); });

        card.off('mouseenter.cc mouseleave.cc').on('mouseenter.cc', function() {
            clearTimeout(hideTimer);
        }).on('mouseleave.cc', function() { scheduleHide(); });

        // 异步 IP
        if (d.ip) {
            $.ajax({
                url: IP_API,
                type: 'GET',
                data: { ip: d.ip },
                dataType: 'json',
                timeout: 3000,
                success: function(r) {
                    if (card && r && r.loc) {
                        card.find('.cc-ip-tag').html('<span class="cc-ip-dot"></span>IP ' + esc(r.loc));
                    }
                }
            });
        }

        // 异步在线检测
        if (d.url && IP_API) {
            $.ajax({
                url: IP_API,
                type: 'GET',
                data: { check: d.url },
                dataType: 'json',
                timeout: 5000,
                success: function(r) {
                    if (!card) return;
                    var $st = card.find('.cc-status');
                    if (r && r.online) {
                        $st.html('<span class="cc-status-dot cc-status-on"></span>在线').addClass('cc-status-online');
                    } else {
                        $st.html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');
                    }
                },
                error: function() {
                    if (card) card.find('.cc-status').html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');
                }
            });
        }
    }

    function scheduleHide() {
        clearTimeout(hideTimer);
        hideTimer = setTimeout(function() { closeCard(); }, 200);
    }

    function closeCard() {
        clearTimeout(hideTimer);
        if (card) { card.addClass('cc-hide'); setTimeout(function() { if (card) { card.remove(); card = null; } }, 180); }
    }

    function positionCard($a, $c) {
        var ao = $a.offset(), aw = $a.outerWidth(), cw = $c.outerWidth(), ww = $(window).width();
        var ch = $c.outerHeight(), st = $(window).scrollTop(), wh = $(window).height();
        var t = ao.top + $a.outerHeight() + 12;
        var l = ao.left + aw / 2 - cw / 2;
        if (l + cw > ww - 12) l = ww - cw - 12;
        if (l < 12) l = 12;
        if (t + ch > st + wh - 12) { t = ao.top - ch - 12; $c.addClass('cc-above'); }
        $c.css({ top: t, left: l });
    }

    function esc(t) { if (typeof t !== 'string') return t; var d = document.createElement('div'); d.appendChild(document.createTextNode(t)); return d.innerHTML; }

    function md5(s) {
        function RL(lV,iS){return(lV<<iS)|(lV>>>(32-iS));}
        function AU(lX,lY){var lX4,lY4,lX8,lY8,lR;lX8=(lX&0x80000000);lY8=(lY&0x80000000);lX4=(lX&0x40000000);lY4=(lY&0x40000000);lR=(lX&0x3FFFFFFF)+(lY&0x3FFFFFFF);if(lX4&lY4)return(lR^0x80000000^lX8^lY8);if(lX4|lY4){if(lR&0x40000000)return(lR^0xC0000000^lX8^lY8);else return(lR^0x40000000^lX8^lY8);}else return(lR^lX8^lY8);}
        function F(x,y,z){return(x&y)|((~x)&z);}function G(x,y,z){return(x&z)|(y&(~z));}function H(x,y,z){return(x^y^z);}function I(x,y,z){return(y^(x|(~z)));}
        function FF(a,b,c,d,x,s,ac){a=AU(a,AU(AU(F(b,c,d),x),ac));return AU(RL(a,s),b);}function GG(a,b,c,d,x,s,ac){a=AU(a,AU(AU(G(b,c,d),x),ac));return AU(RL(a,s),b);}function HH(a,b,c,d,x,s,ac){a=AU(a,AU(AU(H(b,c,d),x),ac));return AU(RL(a,s),b);}function II(a,b,c,d,x,s,ac){a=AU(a,AU(AU(I(b,c,d),x),ac));return AU(RL(a,s),b);}
        function CWA(s){var lWC;var lML=s.length;var lNT1=lML+8;var lNT2=(lNT1-(lNT1%64))/64;var lNW=(lNT2+1)*16;var lWA=new Array(lNW-1);var lBP=0;var lBC=0;while(lBC<lML){lWC=(lBC-(lBC%4))/4;lBP=(lBC%4)*8;lWA[lWC]=(lWA[lWC]|(s.charCodeAt(lBC)<<lBP));lBC++;}lWC=(lBC-(lBC%4))/4;lBP=(lBC%4)*8;lWA[lWC]=lWA[lWC]|(0x80<<lBP);lWA[lNW-2]=lML<<3;lWA[lNW-1]=lML>>>29;return lWA;}
        function WTH(lV){var wTHV='',wTHT='',lB,lC;for(lC=0;lC<=3;lC++){lB=(lV>>>(lC*8))&255;wTHT='0'+lB.toString(16);wTHV=wTHV+wTHT.substr(wTHT.length-2,2);}return wTHV;}
        function UE(s){s=s.replace(/\r\n/g,'\n');var u='';for(var n=0;n<s.length;n++){var c=s.charCodeAt(n);if(c<128){u+=String.fromCharCode(c);}else if((c>127)&&(c<2048)){u+=String.fromCharCode((c>>6)|192);u+=String.fromCharCode((c&63)|128);}else{u+=String.fromCharCode((c>>12)|224);u+=String.fromCharCode(((c>>6)&63)|128);u+=String.fromCharCode((c&63)|128);}}return u;}
        var x=[],k,AA,BB,CC,DD,a,b,c,d;var S11=7,S12=12,S13=17,S14=22;var S21=5,S22=9,S23=14,S24=20;var S31=4,S32=11,S33=16,S34=23;var S41=6,S42=10,S43=15,S44=21;
        s=UE(s);x=CWA(s);a=0x67452301;b=0xEFCDAB89;c=0x98BADCFE;d=0x10325476;
        for(k=0;k<x.length;k+=16){AA=a;BB=b;CC=c;DD=d;a=FF(a,b,c,d,x[k+0],S11,0xD76AA478);d=FF(d,a,b,c,x[k+1],S12,0xE8C7B756);c=FF(c,d,a,b,x[k+2],S13,0x242070DB);b=FF(b,c,d,a,x[k+3],S14,0xC1BDCEEE);a=FF(a,b,c,d,x[k+4],S11,0xF57C0FAF);d=FF(d,a,b,c,x[k+5],S12,0x4787C62A);c=FF(c,d,a,b,x[k+6],S13,0xA8304613);b=FF(b,c,d,a,x[k+7],S14,0xFD469501);a=FF(a,b,c,d,x[k+8],S11,0x698098D8);d=FF(d,a,b,c,x[k+9],S12,0x8B44F7AF);c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);a=FF(a,b,c,d,x[k+12],S11,0x6B901122);d=FF(d,a,b,c,x[k+13],S12,0xFD987193);c=FF(c,d,a,b,x[k+14],S13,0xA679438E);b=FF(b,c,d,a,x[k+15],S14,0x49B40821);a=GG(a,b,c,d,x[k+1],S21,0xF61E2562);d=GG(d,a,b,c,x[k+6],S22,0xC040B340);c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);b=GG(b,c,d,a,x[k+0],S24,0xE9B6C7AA);a=GG(a,b,c,d,x[k+5],S21,0xD62F105D);d=GG(d,a,b,c,x[k+10],S22,0x2441453);c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);b=GG(b,c,d,a,x[k+4],S24,0xE7D3FBC8);a=GG(a,b,c,d,x[k+9],S21,0x21E1CDE6);d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);c=GG(c,d,a,b,x[k+3],S23,0xF4D50D87);b=GG(b,c,d,a,x[k+8],S24,0x455A14ED);a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);d=GG(d,a,b,c,x[k+2],S22,0xFCEFA3F8);c=GG(c,d,a,b,x[k+7],S23,0x676F02D9);b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);a=HH(a,b,c,d,x[k+5],S31,0xFFFA3942);d=HH(d,a,b,c,x[k+8],S32,0x8771F681);c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);a=HH(a,b,c,d,x[k+1],S31,0xA4BEEA44);d=HH(d,a,b,c,x[k+4],S32,0x4BDECFA9);c=HH(c,d,a,b,x[k+7],S33,0xF6BB4B60);b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);d=HH(d,a,b,c,x[k+0],S32,0xEAA127FA);c=HH(c,d,a,b,x[k+3],S33,0xD4EF3085);b=HH(b,c,d,a,x[k+6],S34,0x4881D05);a=HH(a,b,c,d,x[k+9],S31,0xD9D4D039);d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);b=HH(b,c,d,a,x[k+2],S34,0xC4AC5665);a=II(a,b,c,d,x[k+0],S41,0xF4292244);d=II(d,a,b,c,x[k+7],S42,0x432AFF97);c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);b=II(b,c,d,a,x[k+5],S44,0xFC93A039);a=II(a,b,c,d,x[k+12],S41,0x655B59C3);d=II(d,a,b,c,x[k+3],S42,0x8F0CCC92);c=II(c,d,a,b,x[k+10],S43,0xFFE47D);b=II(b,c,d,a,x[k+1],S44,0x85845DD1);a=II(a,b,c,d,x[k+8],S41,0x6FA87E4F);d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);c=II(c,d,a,b,x[k+6],S43,0xA3014314);b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);a=II(a,b,c,d,x[k+4],S41,0xF7537E82);d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);c=II(c,d,a,b,x[k+2],S43,0x2AD7D2BB);b=II(b,c,d,a,x[k+9],S44,0xEB86D391);a=AU(a,AA);b=AU(b,BB);c=AU(c,CC);d=AU(d,DD);}
        return(WTH(a)+WTH(b)+WTH(c)+WTH(d)).toLowerCase();
    }

    /**
     * 初始化 —— 绑定事件 + PJAX 兼容
     */
    function init() {
        readData();

        // 清理旧事件防止重复绑定
        $(document).off('mouseenter.ccard mouseleave.ccard');

        $(document).on('mouseenter.ccard', '#comments img.avatar, #post-comment-list img.avatar', function() {
            showCard($(this));
        }).on('mouseleave.ccard', '#comments img.avatar, #post-comment-list img.avatar', function() {
            scheduleHide();
        });
    }

    // DOM ready 初始化
    if (typeof jQuery !== 'undefined') {
        $(init);
    }

    // PJAX / Turbolinks / 其他即时加载库兼容
    $(document).on('pjax:end turbolinks:load page:loaded ajaxComplete', function() {
        setTimeout(init, 100);
    });

})(jQuery);
