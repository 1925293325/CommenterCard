<?php
/**
 * CommenterCard 评论者信息卡片
 * 
 * @package CommenterCard
 * @author Lin.
 * @version 1.0.0
 * @link https://linyu.live
 * @copyright Lin. (https://linyu.live)
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class CommenterCard_Plugin implements Typecho_Plugin_Interface
{
    const VERSION = '1.0.0';

    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'injectHeader');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'injectFooter');
        return _t('插件已激活');
    }
    public static function deactivate() { return _t('插件已禁用'); }
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Textarea('levelRules', NULL, "0,访客\n10,活跃\n50,元老\n100,达人\n200,大神", _t('等级规则'), _t('评论数,称号')));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('cornerImg', NULL, '/usr/plugins/CommenterCard/img/bg.jpg', _t('背景图'), _t('URL地址')));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('cornerImgOpacity', NULL, '15', _t('透明度'), _t('0-100')));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('authorMail', NULL, '', _t('博主邮箱'), NULL));
    }
    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    public static function injectHeader()
    {
        $f = __DIR__ . '/card.css';
        if (is_readable($f)) echo '<style>' . file_get_contents($f) . '</style>' . "\n";
    }

    public static function injectFooter()
    {
        $cfg = Typecho_Widget::widget('Widget_Options')->plugin('CommenterCard') ?: new stdClass();
        $db = Typecho_Db::get();

        // 等级规则
        $rules = array();
        foreach (explode("\n", $cfg->levelRules ?? '') as $l) {
            $l = trim($l); if (!$l) continue;
            $p = explode(',', $l, 2);
            if (count($p) === 2) $rules[] = array(intval($p[0]), trim($p[1]));
        }
        usort($rules, function($a, $b) { return $a[0] - $b[0]; });

        // 背景图处理
        $cImg = trim($cfg->cornerImg ?? '');
        $bg = (empty($cImg) || strpos($cImg, '/usr/plugins/') === 0)
            ? Helper::options()->pluginUrl . '/CommenterCard/img/bg.jpg' : $cImg;
        $op = max(0, min(100, intval($cfg->cornerImgOpacity ?? 15)));
        $aMail = strtolower(trim($cfg->authorMail ?? ''));

        // 取最近100条评论聚合
        $rows = $db->fetchAll($db->select('mail','author','url','ip','created','text')
            ->from('table.comments')->where('status=?','approved')
            ->order('created', Typecho_Db::SORT_DESC)->limit(100));

        $u = array(); // 按邮箱聚合
        foreach ($rows as $r) {
            $mk = strtolower(trim($r['mail']??'')); if (!$mk) continue;
            if (!isset($u[$mk])) $u[$mk] = array('n'=>$r['author']??'','u'=>$r['url']??'','i'=>$r['ip']??'','t'=>intval($r['created']??0),'c'=>0,'r'=>array());
            $u[$mk]['c']++;
            if (count($u[$mk]['r'])<3) $u[$mk]['r'][] = array(mb_strimwidth(strip_tags($r['text']??''),0,28,'…','UTF-8'), date('m-d H:i',intval($r['created'])));
        }

        // 生成数据
        $d = array(); $n = array();
        foreach ($u as $mk=>$v) {
            $lv = '';
            foreach ($rules as $rl) { if ($rl[0] <= $v['c']) $lv = $rl[1]; }
            $nm = $v['n'] ?: '访客';
            $au = !empty($aMail) && $mk === $aMail;
            $item = array('name'=>$nm,'url'=>$v['u'],'count'=>$v['c'],'level'=>$lv,'ip'=>$v['i'],'lastTime'=>$v['t']?date('Y-m-d H:i',$v['t']):'','recent'=>$v['r'],'author'=>$au);
            $d[md5($mk)] = $item;
            if (!isset($n[$nm])) $n[$nm] = $item;
        }

        // 输出：数据 + JS 全部内联
        echo '<script>window._ccd='.json_encode($d).';window._ccn='.json_encode($n).';window._cci='.json_encode($bg).';window._cco='.$op.';window._ccp='.json_encode(Helper::options()->pluginUrl.'/CommenterCard/ip.php').';window._ccv=2;</script>';
        $j = __DIR__.'/card.js';
        if (is_readable($j)) echo '<script>'.file_get_contents($j).'</script>';
    }
}
