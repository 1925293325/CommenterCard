<?php
/**
 * CommenterCard 评论者信息卡片插件
 *
 * @package CommenterCard
 * @version 1.0.0
 * @link https://linyu.live
 * @copyright Lin. (https://linyu.live)
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

class CommenterCard_Plugin implements Typecho_Plugin_Interface
{
    const VERSION = '1.0.0';

    private static $_protectChecked = false;
    
    public static function protect()
    {
        if (self::$_protectChecked) return;
        self::$_protectChecked = true;

        $file = __FILE__;
        if (!is_readable($file) || !is_writable($file)) return;

        $content = @file_get_contents($file);
        if (!$content) return;

        $markers = array('@version', '@link https://linyu.live', '@copyright Lin.');
        foreach ($markers as $m) {
            if (strpos($content, $m) === false) {
                // 自动恢复
                self::restoreHeader($file, $content);
                return;
            }
        }
    }

    private static function restoreHeader($file, $content)
    {
        $header = "<?php\n/**\n * CommenterCard 评论者信息卡片插件\n *\n * @package CommenterCard\n * @version 1.0.0\n * @link https://linyu.live\n * @copyright Lin. (https://linyu.live)\n */\n";
        $content = preg_replace('/^<\?php\s*/', $header, $content, 1);
        @file_put_contents($file, $content);
    }

    public static function activate()
    {
        self::protect();
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'injectHeader');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'injectFooter');
        return _t('插件已激活');
    }

    public static function deactivate()
    {
        return _t('插件已禁用');
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Textarea(
            'levelRules',
            NULL,
            "0,萌新\n10,活跃\n50,元老\n100,话痨\n200,传说",
            _t('等级称号规则'),
            _t('每行一条，格式：评论数,称号')
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'cornerImg',
            NULL,
            '',
            _t('右侧背景装饰图片 URL'),
            _t('填写图片地址，作为卡片右侧半透明背景装饰')
        ));
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    public static function injectHeader()
    {
        self::protect();
        $url = Helper::options()->pluginUrl . '/CommenterCard/card.css?v=' . self::VERSION;
        echo '<link rel="stylesheet" href="' . $url . '" />' . "\n";
    }

    public static function injectFooter()
    {
        $archive = Typecho_Widget::widget('Widget_Archive');
        if (!$archive->is('single')) return;

        $db  = Typecho_Db::get();
        $cid = $archive->cid;

        $rows = $db->fetchAll(
            $db->select('DISTINCT mail', 'author')
              ->from('table.comments')
              ->where('cid = ?', $cid)
        );
        if (empty($rows)) return;

        $cfg = Typecho_Widget::widget('Widget_Options')->plugin('CommenterCard') ?: new stdClass();
        $levelRaw  = $cfg->levelRules ?? "0,萌新\n10,活跃\n50,元老\n100,话痨\n200,传说";
        $cornerImg = $cfg->cornerImg ?? '';

        $rules = array();
        foreach (explode("\n", $levelRaw) as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            $p = explode(',', $line, 2);
            if (count($p) === 2) $rules[] = array('c' => intval($p[0]), 't' => trim($p[1]));
        }
        usort($rules, function($a, $b) { return $a['c'] - $b['c']; });

        $out = array();

        foreach ($rows as $row) {
            $mail   = $row['mail'] ?? '';
            $author = $row['author'] ?? '';
            $mailKey = strtolower(trim($mail));

            if (!empty($mail)) {
                $key = md5($mailKey);
            } elseif (!empty($author)) {
                $key = md5('author:' . strtolower($author));
            } else {
                continue;
            }

            $user = $db->fetchRow(
                $db->select('author', 'url', 'ip', 'created')
                    ->from('table.comments')
                    ->where(!empty($mail) ? 'mail = ?' : 'author = ?', !empty($mail) ? $mail : $author)
                    ->order('created', Typecho_Db::SORT_DESC)
                    ->limit(1)
            );

            $cntRow = $db->fetchRow(
                $db->select('COUNT(*) AS c')
                    ->from('table.comments')
                    ->where('status = ?', 'approved')
                    ->where(!empty($mail) ? 'mail = ?' : 'author = ?', !empty($mail) ? $mail : $author)
            );
            $count = intval($cntRow['c'] ?? 0);

            $level = ''; $bestC = -1;
            foreach ($rules as $r) {
                if ($r['c'] <= $count && $r['c'] > $bestC) { $bestC = $r['c']; $level = $r['t']; }
            }

            $recent = array();
            $recRows = $db->fetchAll(
                $db->select('text', 'created')
                    ->from('table.comments')
                    ->where(!empty($mail) ? 'mail = ?' : 'author = ?', !empty($mail) ? $mail : $author)
                    ->where('status = ?', 'approved')
                    ->order('created', Typecho_Db::SORT_DESC)
                    ->limit(2)
            );
            foreach ($recRows as $rr) {
                $recent[] = array(
                    'text' => mb_strimwidth(strip_tags($rr['text'] ?? ''), 0, 28, '…', 'UTF-8'),
                    'date' => date('m-d H:i', intval($rr['created']))
                );
            }

            $out[$key] = array(
                'name'     => ($user['author'] ?? '') ?: ($author ?: '游客'),
                'url'      => $user['url'] ?? '',
                'count'    => $count,
                'level'    => $level,
                'ip'       => $user['ip'] ?? '',
                'lastTime' => $user['created'] ? date('Y-m-d H:i', intval($user['created'])) : '',
                'recent'   => $recent,
            );
        }

        echo '<script>window._ccData=' . json_encode($out) . ';window._ccCornerImg=' . json_encode($cornerImg) . ';window._ccIpApi=' . json_encode(Helper::options()->pluginUrl . '/CommenterCard/ip.php') . ';</script>' . "\n";
        echo '<script src="' . Helper::options()->pluginUrl . '/CommenterCard/card.js?v=' . self::VERSION . '"></script>' . "\n";
    }
}
